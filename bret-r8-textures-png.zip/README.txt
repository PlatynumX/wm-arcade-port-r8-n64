WWF WrestleMania Arcade - Bret Hart frames used by N64 r8/r8h1

frames/ contains exact WIMP CI8 source frames converted to RGBA PNG.
Palette index 0 is transparent. No scaling, smoothing or cleanup was applied.
bret-r8-frame-metadata.csv preserves image dimensions, animation origins,
the hardware-tested channel-2 raw attachment pair (+38/+40 = tail 3/4),
palette name/count, and all nine preserved WIMP tail words.
Frame count: 177
