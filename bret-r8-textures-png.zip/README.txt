WWF WrestleMania Arcade - Bret Hart frames used by the N64 r8 port

frames/ contains the exact WIMP CI8 source frames converted to RGBA PNG.
Palette index 0 is transparent. No resizing or cleanup was applied.
bret-r8-frame-metadata.csv preserves dimensions, animation origin and WIMP tail words.
The hardware-tested channel-2 attachment pair is raw tail slot 3/4 (+38/+40).
Frame count: 145
WIMP containers: 4
